//
//  TableViewCell.swift
//  IML Taxi
//
//  Created by sravan yadav on 24/12/23.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var offerLbl: UILabel!
    @IBOutlet var dollerLbl: UILabel!
    @IBOutlet var blackImgV: UIImageView!
    @IBOutlet var carImgV: UIImageView!
    @IBOutlet var starImgV: UIImageView!
    @IBOutlet var NextRideLbl: UILabel!
    @IBOutlet var saveLable: UILabel!
    @IBOutlet var backGroundView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
