//
//  NotificationViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 25/12/23.
//

import UIKit

class NotificationViewController: UIViewController {

    @IBOutlet var BackBtn: UIButton!
    @IBOutlet var tableV: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let revealController : SWRevealViewController = self.revealViewController()
        BackBtn.addTarget(revealController, action: #selector(SWRevealViewController().revealToggle(_:)), for: .touchUpInside)
        tableV.register(UINib(nibName: "NotificationTableViewCell", bundle: nil), forCellReuseIdentifier: "NotificationTableViewCell")
    }
    
    @IBAction func tapsOnBackBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension NotificationViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationTableViewCell") as! NotificationTableViewCell
        cell.imgV.layer.cornerRadius = cell.imgV.frame.size.height/2
        switch indexPath.row % 5{
           case 1:
               cell.systemLbl.text = "Promotion"
            cell.BookingLbl.text = "Invite Friends Get-3 Coupons each!"
            case 2:
               cell.systemLbl.text = "Promotion"
            cell.BookingLbl.text = "Invite Friends Get-3 Coupons each!"
            case 3:
              cell.systemLbl.text = "System"
              cell.BookingLbl.text = "Booking#1354 has been Successed"
            case 4:
               cell.systemLbl.text = "Promotion"
               cell.BookingLbl.text = "Invite Friends Get-3 Coupons each!"
            case 5:
               cell.systemLbl.text = "System"
               cell.BookingLbl.text = "Booking#1234 has been Successed"
            case 6:
               cell.systemLbl.text = "Promotion"
               cell.BookingLbl.text = "Invite Friends Get-3 Coupons each!"
                     default: break
           }
        return cell
        
    }
}
