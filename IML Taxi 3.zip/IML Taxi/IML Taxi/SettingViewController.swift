//
//  SettingViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 25/12/23.
//

import UIKit

class SettingViewController: UIViewController {
    
    @IBOutlet var arabicBtn: UIButton!
    @IBOutlet var EnglishBtn: UIButton!
    @IBOutlet var BackBtn: UIButton!
    @IBOutlet var privacyTextField: UITextField!
    @IBOutlet var workTextField: UITextField!
    @IBOutlet var homeTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let revealController : SWRevealViewController = self.revealViewController()
        BackBtn.addTarget(revealController, action: #selector(SWRevealViewController().revealToggle(_:)), for: .touchUpInside)
        
        
        homeTextField.layer.borderWidth = 1
        homeTextField.layer.borderColor = UIColor.white.cgColor
        privacyTextField.layer.borderWidth = 1
        privacyTextField.layer.borderColor = UIColor.white.cgColor
        workTextField.layer.borderWidth = 1
        workTextField.layer.borderColor = UIColor.white.cgColor
    }
    @IBAction func tapsOnBackBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func tapsOnArabicBtnAct(_ sender: Any) {
        arabicBtn.setImage(UIImage(named: "radio-button"), for: .normal)
        EnglishBtn.setImage(UIImage(named: "Check Box (9)"), for: .normal)
    }
    @IBAction func tapsOnEnglishBtnAction(_ sender: Any) {
        arabicBtn.setImage(UIImage(named: "Check Box (9)"), for: .normal)
        EnglishBtn.setImage(UIImage(named: "radio-button"), for: .normal)
        
    }
}
