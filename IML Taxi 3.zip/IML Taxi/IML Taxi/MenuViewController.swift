//
//  MenuViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 25/12/23.
//

import UIKit

class MenuViewController: UIViewController {
    var arrayofnames = ["Home","Payment","Your Trips","Offers","Wallet","Passbook","Settings","Notification Manager","Help","Share","Become a Driver","Logout"]
    var arrayofImages = ["home (1)","Combined Shape","airplane (1)","offer (2)","wallet-2","passbook 1","Setting","Notificatification","Help","Share","Become a Driver","logout"]
    @IBOutlet var tableV: UITableView!
    @IBOutlet var BgView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        BgView.layer.cornerRadius = BgView.frame.size.height/2
        tableV.register(UINib(nibName: "MenuTableViewCell", bundle: nil).self, forCellReuseIdentifier: "MenuTableViewCell")
        tableV.layer.cornerRadius = 30
        
    }
}
extension MenuViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 12
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTableViewCell", for: indexPath) as! MenuTableViewCell
        cell.PaymentLbl.text = arrayofnames[indexPath.row]
        cell.ImgV.image = UIImage(named: arrayofImages[indexPath.row])
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var destinationController = UIViewController()
        let name = arrayofnames[indexPath.row]
        if name == "Payment"{
            destinationController = self.storyboard?.instantiateViewController(withIdentifier: "PaymentViewController") as! PaymentViewController
            let navController = UINavigationController.init(rootViewController: destinationController)
            navController.navigationBar.isHidden = true
            let reveal_Controller: SWRevealViewController = self.revealViewController()
            reveal_Controller.setFront(navController, animated: false)
            reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
            
        }else if name == "Settings"{
            destinationController = self.storyboard?.instantiateViewController(withIdentifier: "SettingViewController") as! SettingViewController
            let navController = UINavigationController.init(rootViewController: destinationController)
            navController.navigationBar.isHidden = true
            let reveal_Controller: SWRevealViewController = self.revealViewController()
            reveal_Controller.setFront(navController, animated: true)
            reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
            
        }else {
            if name == "Your Trips"{
              let destinationController = self.storyboard?.instantiateViewController(withIdentifier: "PassBookViewController") as! PassBookViewController
                let navController = UINavigationController.init(rootViewController: destinationController)
                navController.navigationBar.isHidden = true
                let reveal_Controller: SWRevealViewController = self.revealViewController()
                reveal_Controller.setFront(navController, animated: false)
                reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                destinationController.urlStr = "https://www.mittag-leffler.se/for-visitors/visit-us/"
            }else {
                if name == "Offers"{
                    destinationController = self.storyboard?.instantiateViewController(withIdentifier: "OffersViewController") as! OffersViewController
                    let navController = UINavigationController.init(rootViewController: destinationController)
                    navController.navigationBar.isHidden = true
                    let reveal_Controller: SWRevealViewController = self.revealViewController()
                    reveal_Controller.setFront(navController, animated: true)
                    reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                    
                }else {
                    if name == "Wallet"{
                        destinationController = self.storyboard?.instantiateViewController(withIdentifier: "WalletViewController") as! WalletViewController
                        let navController = UINavigationController.init(rootViewController: destinationController)
                        navController.navigationBar.isHidden = true
                        let reveal_Controller: SWRevealViewController = self.revealViewController()
                        reveal_Controller.setFront(navController, animated: true)
                        reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                        
                    }else {
                        if name == "Passbook"{
                           let destinationController = self.storyboard?.instantiateViewController(withIdentifier: "PassBookViewController") as! PassBookViewController
                            let navController = UINavigationController.init(rootViewController: destinationController)
                            navController.navigationBar.isHidden = true
                            let reveal_Controller: SWRevealViewController = self.revealViewController()
                            reveal_Controller.setFront(navController, animated: true)
                            reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                            destinationController.urlStr = "https://www.mittag-leffler.se/for-visitors/visit-us/"
                        }else {
                            if name == "Notification Manager"{
                                destinationController = self.storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
                                let navController = UINavigationController.init(rootViewController: destinationController)
                                navController.navigationBar.isHidden = true
                                let reveal_Controller: SWRevealViewController = self.revealViewController()
                                reveal_Controller.setFront(navController, animated: true)
                                reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                                
                            }else {
                                if name == "Help"{
                                    let destinationController = self.storyboard?.instantiateViewController(withIdentifier: "PassBookViewController") as! PassBookViewController
                                     let navController = UINavigationController.init(rootViewController: destinationController)
                                     navController.navigationBar.isHidden = true
                                     let reveal_Controller: SWRevealViewController = self.revealViewController()
                                     reveal_Controller.setFront(navController, animated: true)
                                     reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                                     destinationController.urlStr = "https://www.mittag-leffler.se/for-visitors/visit-us/"
                                }else{
                                    if name == "Share"{
                                        let destinationController = self.storyboard?.instantiateViewController(withIdentifier: "PassBookViewController") as! PassBookViewController
                                         let navController = UINavigationController.init(rootViewController: destinationController)
                                         navController.navigationBar.isHidden = true
                                         let reveal_Controller: SWRevealViewController = self.revealViewController()
                                         reveal_Controller.setFront(navController, animated: true)
                                         reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                                        destinationController.urlStr = "https://www.blablacar.in/"
                                    }else {
                                        if name == "Become a Driver"{
                                            let destinationController = self.storyboard?.instantiateViewController(withIdentifier: "PassBookViewController") as! PassBookViewController
                                             let navController = UINavigationController.init(rootViewController: destinationController)
                                             navController.navigationBar.isHidden = true
                                             let reveal_Controller: SWRevealViewController = self.revealViewController()
                                             reveal_Controller.setFront(navController, animated: true)
                                             reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                                            destinationController.urlStr = "https://www.makemytrip.com/car-rental/hyderabad-city-cabs.html"
                                        }else {
                                            if name == "Logout"{
                                                var navigateController = UIViewController()
                                                UserDefaults.standard.set(false, forKey: "LoginKey")
                                                UserDefaults.standard.synchronize()
                                                navigateController = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
                                                let navController = UINavigationController.init(rootViewController: navigateController)
                                                navController.navigationBar.isHidden = true
                                                let reveal_Controller: SWRevealViewController = self.revealViewController()
                                                reveal_Controller.setFront(navController, animated: false)
                                                reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                                            }else {
                                                if name == "Home"{
                                                    destinationController = self.storyboard?.instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
                                                    let navController = UINavigationController.init(rootViewController: destinationController)
                                                    navController.navigationBar.isHidden = true
                                                    let reveal_Controller: SWRevealViewController = self.revealViewController()
                                                    reveal_Controller.setFront(navController, animated: true)
                                                    reveal_Controller.setFrontViewPosition(FrontViewPosition.left, animated: true)
                                                    
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
    }
}
