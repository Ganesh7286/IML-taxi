//
//  PassBookViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 29/12/23.
//

import UIKit
import WebKit
import ProgressHUD

class PassBookViewController: UIViewController,WKNavigationDelegate {
    var webView : WKWebView!
    var urlStr:String?
    @IBOutlet var BackBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        //        let revealController : SWRevealViewController = self.revealViewController()
        //        BackBtn.addTarget(revealController, action: #selector(SWRevealViewController().revealToggle(_:)), for: .touchUpInside)
        //
        let myBlog = urlStr
        let url = NSURL(string: myBlog!)
        let request = NSURLRequest(url: url! as URL)
        
        // init and load request in webview.
        webView = WKWebView(frame: CGRect(x: 0, y: 100, width: self.view.frame.size.width, height: self.view.frame.size.height))
        webView.navigationDelegate = self
        webView.load(request as URLRequest)
        self.view.addSubview(webView)
        self.view.sendSubviewToBack(webView)
    }
    private func webView(webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: NSError) {
        print(error.localizedDescription)
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        ProgressHUD.colorBackground = .red
        ProgressHUD.animate("Some text...")
        ProgressHUD.animationType = .activityIndicator
        ProgressHUD.colorHUD = .systemGray
        print("Strat to load")
    }
    @objc(webView:didFinishNavigation:) func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("finish to load")
        ProgressHUD.dismiss()
    }
    @IBAction func tapsOnBackBtnAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
        self.navigationController?.pushViewController(destinationVC, animated: true)
//        self.navigationController?.popViewController(animated: true)

        ProgressHUD.dismiss()
    }
}
    



