//
//  ViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 23/12/23.
//



import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var mobileNumTextField: UITextField!
    @IBOutlet var backV: UIView!
    @IBOutlet var nextBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        nextBtn.layer.cornerRadius = nextBtn.frame.size.height/2
        backV.layer.borderWidth = 1
        backV.layer.borderColor = UIColor.systemGray.cgColor
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        self.view.addGestureRecognizer(tap)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
    @IBAction func nextBtnAction(_ sender: Any) {
        guard let phoneNumber = mobileNumTextField.text, !phoneNumber.isEmpty else {
            showAlert(withTitle: "Alert", withMessage: "Enter Mobile Number")
            return
        }
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "VerifyViewController") as! VerifyViewController
        destinationVC.phoneNumber = phoneNumber // Pass the phone number to VerifyViewController
        self.navigationController?.pushViewController(destinationVC, animated: true)
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        mobileNumTextField.resignFirstResponder()
    }
    
    func showAlert(withTitle title: String, withMessage message:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(ok)
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
    }
}

extension ViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let newLength = (textField.text?.utf16.count)! + string.utf16.count - range.length
        return newLength <= 10
    }
}
