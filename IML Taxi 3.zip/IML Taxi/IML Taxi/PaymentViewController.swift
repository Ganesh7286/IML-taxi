//
//  PaymentViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 25/12/23.
//

import UIKit

class PaymentViewController: UIViewController {

    @IBOutlet var BackBtn: UIButton!
    @IBOutlet var voucherTextField: UITextField!
    @IBOutlet var promoTextField: UITextField!
    @IBOutlet var paymentTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let revealController : SWRevealViewController = self.revealViewController()
        BackBtn.addTarget(revealController, action: #selector(SWRevealViewController().revealToggle(_:)), for: .touchUpInside)
    
        promoTextField.layer.borderWidth = 1
        promoTextField.layer.borderColor = UIColor.white.cgColor
        voucherTextField.layer.borderWidth = 1
        voucherTextField.layer.borderColor = UIColor.white.cgColor
        paymentTextField.layer.borderWidth = 1
        paymentTextField.layer.borderColor = UIColor.white.cgColor
    }
    
    @IBAction func tapsOnBackBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
}
