//
//  RegisterViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 23/12/23.
//

import UIKit

class RegisterViewController: UIViewController {
    
    @IBOutlet var registerBtn: UIButton!
    @IBOutlet var conformTxtFld: UITextField!
    @IBOutlet var passwordTxtFld: UITextField!
    @IBOutlet var NumberTextField: UITextField!
    @IBOutlet var PhTextField: UITextField!
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var lastNameTextField: UITextField!
    @IBOutlet var firstNameTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        firstNameTextField.layer.borderWidth = 1
        firstNameTextField.layer.borderColor = UIColor.white.cgColor
        lastNameTextField.layer.borderWidth = 1
        lastNameTextField.layer.borderColor = UIColor.white.cgColor
        emailTextField.layer.borderWidth = 1
        emailTextField.layer.borderColor = UIColor.white.cgColor
        PhTextField.layer.borderWidth = 1
        PhTextField.layer.borderColor = UIColor.white.cgColor
        NumberTextField.layer.borderWidth = 1
        NumberTextField.layer.borderColor = UIColor.white.cgColor
        passwordTxtFld.layer.borderWidth = 1
        passwordTxtFld.layer.borderColor = UIColor.white.cgColor
        conformTxtFld.layer.borderWidth = 1
        conformTxtFld.layer.borderColor = UIColor.white.cgColor
        registerBtn.layer.cornerRadius  = registerBtn.frame.size.height/2
    }
    @IBAction func tapsOnRegisterBtnActn(_ sender: Any) {
        if firstNameTextField.text?.count == 0{
            showAlert(withTitle: "Alert", withMessage: "First Name")
        }else if lastNameTextField.text?.count == 0{
            showAlert(withTitle: "Alert", withMessage: "Last Name")
        }else if emailTextField.text?.count == 0{
            showAlert(withTitle: "Alert", withMessage: "Email")
        }else if NumberTextField.text?.count == 0{
            showAlert(withTitle: "Alert", withMessage: "Phone Number")
        }else if passwordTxtFld.text?.count == 0{
            showAlert(withTitle: "Alert", withMessage: "Password")
        }else if conformTxtFld.text?.count == 0{
            showAlert(withTitle: "Alert", withMessage: "Conform Password")
        }else {
            print(firstNameTextField.text ?? "")
            print(lastNameTextField.text ?? "")
            print(emailTextField.text ?? "")
            print(NumberTextField.text ?? "")
            print(passwordTxtFld.text ?? "")
            print(conformTxtFld.text ?? "")
            _ = UIViewController()
            UserDefaults.standard.set(true, forKey: "LoginKey")
            UserDefaults.standard.synchronize()
            let scene = UIApplication.shared.connectedScenes.first
            if let sd:SceneDelegate = (scene?.delegate as? SceneDelegate){
                sd.getHomeScreenController()
            }
        }
    }
@IBAction func backBtnAction(_ sender: Any) {
self.navigationController?.popViewController(animated:  true)
    }
    func showAlert(withTitle title: String, withMessage message:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
        })
        //    let cancel = UIAlertAction(title: "Cancel", style: .default, handler: { action in
        //    })
        alert.addAction(ok)
        //    alert.addAction(cancel)
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
    }
}
extension RegisterViewController:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
