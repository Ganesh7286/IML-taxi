//
//  MapViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 25/12/23.
//

import UIKit
import MapKit
import CoreLocation
class MapViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate{
    @IBOutlet var secondTextField: UITextField!
    @IBOutlet var firstTextField: UITextField!
    @IBOutlet var mapV: MKMapView!
    let locationManager = CLLocationManager()
    @IBOutlet var menuButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        firstTextField.layer.borderWidth = 1
        firstTextField.layer.borderColor = UIColor.white.cgColor
        firstTextField.clipsToBounds = true
        firstTextField.layer.backgroundColor = UIColor.white.cgColor
        firstTextField.layer.cornerRadius = 20
        firstTextField.clipsToBounds = true
        secondTextField.layer.borderWidth = 1
        secondTextField.layer.borderColor = UIColor.white.cgColor
        secondTextField.clipsToBounds = true
        secondTextField.layer.backgroundColor = UIColor.white.cgColor
        secondTextField.layer.cornerRadius = 20
        secondTextField.clipsToBounds = true
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        let revealController : SWRevealViewController = self.revealViewController()
        menuButton.addTarget(revealController, action: #selector(SWRevealViewController().revealToggle(_:)), for: .touchUpInside)
        let london = MKPointAnnotation()
        let turkey = MKPointAnnotation()
        let India = MKPointAnnotation()
        let Telangana = MKPointAnnotation()
        let warangal = MKPointAnnotation()
        let Kanmukkula = MKPointAnnotation()
        Kanmukkula.title = "Kanmukkula"
        london.title = "London"
        turkey.title = "Turkey"
        India.title = "India"
        Telangana.title = "Telangana"
        warangal.title = "warangal"
        
        
        london.coordinate = CLLocationCoordinate2D(latitude: 51.507222, longitude: -0.1275)
        turkey.coordinate = CLLocationCoordinate2D(latitude: 39.1667, longitude: 35.6667)
        India.coordinate = CLLocationCoordinate2D(latitude: 20.5937, longitude: 78.9629)
        Telangana.coordinate = CLLocationCoordinate2D(latitude: 17.20, longitude: 78.30)
        warangal.coordinate = CLLocationCoordinate2D(latitude: 17.58, longitude: 79.40)
        Kanmukkula.coordinate = CLLocationCoordinate2D(latitude: 17.3358, longitude:  78.8487)
        
        mapV.addAnnotation(london)
        mapV.addAnnotation(turkey)
        mapV.addAnnotation(India)
        mapV.addAnnotation(Telangana)
        mapV.addAnnotation(warangal)
        mapV.addAnnotation(Kanmukkula)

    }
    
    private func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        print(error.localizedDescription)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        
        let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "customannotation")
        annotationView.image = UIImage(named: "Cars")
        annotationView.canShowCallout = true
        
        return annotationView
        
    }
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
               guard let location = locations.last else { return }
               let coordinate = location.coordinate
               print("Latitude: \(coordinate.latitude), Longitude: \(coordinate.longitude)")
                   let region = MKCoordinateRegion(
                       center: coordinate,
                       latitudinalMeters: 700,
                       longitudinalMeters: 700
                   )
                   mapV.setRegion(region, animated: true)
               }
        func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
                print("Location manager error: \(error.localizedDescription)")
            }
    
    
}
