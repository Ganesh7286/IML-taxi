//
//  WalletViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 25/12/23.
//

import UIKit
class WalletViewController:UIViewController {
    @IBOutlet var BackBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        let revealController : SWRevealViewController = self.revealViewController()
        BackBtn.addTarget(revealController, action: #selector(SWRevealViewController().revealToggle(_:)), for: .touchUpInside)
    }
    @IBAction func TapsOnBackBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
