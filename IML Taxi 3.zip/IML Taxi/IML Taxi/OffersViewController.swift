//
//  OffersViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 24/12/23.
//

import UIKit

class OffersViewController: UIViewController {
// var arrayofnames = [
    @IBOutlet var tableV: UITableView!
    @IBOutlet var MenuBtn: UIButton!
    var arrayofCars = ["Bitmap","car","Bitmap","car","Bitmap"]
    var arrayofImges = ["Stars","Empty","Stars","Empty","Stars"]
    var arrayofdoller = ["$20","$15","$20","$15","$20"]
    var arrayofViewColor = ["Brinjal","system Yellow","Brinjal","System Yellow","Brinjal"]
    override func viewDidLoad() {
        super.viewDidLoad()
        let revealController : SWRevealViewController = self.revealViewController()
        MenuBtn.addTarget(revealController, action: #selector(SWRevealViewController().revealToggle(_:)), for: .touchUpInside)
 
        // Do any additional setup after loading the view.
        tableV.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
    }

    @IBAction func tapsOnBackBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension OffersViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        cell.selectionStyle = .none
        cell.carImgV.image = UIImage(named: arrayofCars[indexPath.row])
        cell.starImgV.image = UIImage(named: arrayofImges[indexPath.row])
        cell.starImgV.frame = CGRectMake(0,0,62,62);
        cell.dollerLbl.text = arrayofdoller[indexPath.row]
        switch indexPath.row % 4 {
           case 0:
               cell.backGroundView.backgroundColor = .systemPurple
           case 1:
               cell.backGroundView.backgroundColor = .systemYellow
           case 2:
               cell.backGroundView.backgroundColor = .systemPurple
           case 3:
               cell.backGroundView.backgroundColor = .systemYellow
           default: break
           }
        switch indexPath.row % 4 {
           case 1:
               cell.saveLable.textColor = .black
              cell.NextRideLbl.textColor = .black
           case 3:
               cell.saveLable.textColor = .black
            cell.NextRideLbl.textColor = .black
           default: break
           }
        
        return cell
        
    }
}
