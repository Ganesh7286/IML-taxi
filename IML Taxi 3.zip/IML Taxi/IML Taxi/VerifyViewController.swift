//
//  VerifyViewController.swift
//  IML Taxi
//
//  Created by sravan yadav on 23/12/23.
//

import UIKit

class VerifyViewController: UIViewController {
    
    @IBOutlet var sixthTextField: UITextField!
    @IBOutlet var fifthTxtField: UITextField!
    @IBOutlet var fourthTextFld: UITextField!
    @IBOutlet var thirdTxtField: UITextField!
    @IBOutlet var secondTxtField: UITextField!
    @IBOutlet var firstTxtField: UITextField!
    @IBOutlet var continueBtn: UIButton!
    
    @IBOutlet var numberLabel: UILabel!
    
    var phoneNumber: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        continueBtn.layer.cornerRadius = 13
        
        firstTxtField.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        secondTxtField.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        thirdTxtField.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        fourthTextFld.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        fifthTxtField.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        sixthTextField.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        
        
        numberLabel.text = phoneNumber
    }
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func textFieldDidChange(textField: UITextField){
        let text = textField.text
        if  text?.count == 1 {
            switch textField{
            case firstTxtField:
                secondTxtField.becomeFirstResponder()
            case secondTxtField:
                thirdTxtField.becomeFirstResponder()
            case thirdTxtField:
                fourthTextFld.becomeFirstResponder()
            case fourthTextFld:
                fifthTxtField.becomeFirstResponder()
            case fifthTxtField:
                sixthTextField.becomeFirstResponder()
            case sixthTextField:
                sixthTextField.resignFirstResponder()
            default:
                break
            }
        }
        if  text?.count == 0 {
            switch textField{
            case firstTxtField:
                firstTxtField.becomeFirstResponder()
            case secondTxtField:
                firstTxtField.becomeFirstResponder()
            case thirdTxtField:
                secondTxtField.becomeFirstResponder()
            case fourthTextFld:
                thirdTxtField.becomeFirstResponder()
            case fifthTxtField:
                fourthTextFld.becomeFirstResponder()
            case sixthTextField:
                fifthTxtField.becomeFirstResponder()
            default:
                break
            }
        }
        else{
            
        }
    }
    
    @IBAction func tapsOnContinueBtnAct(_ sender: Any) {
        // Your continue button action
    }
    
    func showAlert(withTitle title: String, withMessage message:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
        })
        alert.addAction(ok)
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
    }
}
